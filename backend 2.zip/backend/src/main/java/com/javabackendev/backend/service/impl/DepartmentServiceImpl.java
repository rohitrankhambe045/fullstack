package com.javabackendev.backend.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.javabackendev.backend.dto.DepartmentDto;
import com.javabackendev.backend.entity.Department;
import com.javabackendev.backend.exception.ResourceNotFoundException;
import com.javabackendev.backend.mapper.DepartmentMapper;
import com.javabackendev.backend.repository.DepartmentRepository;
import com.javabackendev.backend.service.DepartmentService;

@Service
public class DepartmentServiceImpl implements DepartmentService {

	
	public DepartmentServiceImpl(DepartmentRepository departmentRepository) {
		super();
		this.departmentRepository = departmentRepository;
	}
	private DepartmentRepository departmentRepository;
	@Override
	public DepartmentDto createDepartment(DepartmentDto departmentdto) {
	
		Department department = DepartmentMapper.mapToDepartment(departmentdto);
		Department savedDepartment = departmentRepository.save(department);
		return DepartmentMapper.mapToDepartmentDto(savedDepartment);
		
	}
	@Override
	public DepartmentDto getDepartmentById(Long departmentId) {
		Department department = departmentRepository.findById(departmentId).orElseThrow(()-> new ResourceNotFoundException("Department is not exist"+departmentId));
		// TODO Auto-generated method stub
		return DepartmentMapper.mapToDepartmentDto(department);
	}
	@Override
	public List<DepartmentDto> getAllDepartments() {
		List<Department> departments = departmentRepository.findAll();
		
		// TODO Auto-generated method stub
		return departments.stream().map((department) -> DepartmentMapper.mapToDepartmentDto(department)).collect(Collectors.toList());
		
	}
	@Override
	public DepartmentDto updateDepartment(Long departmentId, DepartmentDto updatedDepartment) {
		
		Department department = departmentRepository.findById(departmentId).orElseThrow(()->new ResourceNotFoundException("department not found with id"+departmentId));
		department.setDepartmentName(updatedDepartment.getDepartmentName());
		department.setDepartmentDescription(updatedDepartment.getDepartmentDescription());
		Department savedDepartment = departmentRepository.save(department);
		return DepartmentMapper.mapToDepartmentDto(savedDepartment);
		
		

	}
	@Override
	public void deleteDepartment(Long departmentId) {
		// TODO Auto-generated method stub
		
		departmentRepository.findById(departmentId).orElseThrow(()-> new ResourceNotFoundException("department is not exist with given id"+departmentId));
		departmentRepository.deleteById(departmentId);
		
		
		
	}

}
