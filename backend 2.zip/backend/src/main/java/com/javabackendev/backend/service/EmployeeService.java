package com.javabackendev.backend.service;

import java.util.List;

import com.javabackendev.backend.dto.EmployeeDto;

public interface EmployeeService {
	EmployeeDto createEmployee(EmployeeDto employeeDto);

    EmployeeDto getEmployeeById(int employeeId);

    List<EmployeeDto> getAllEmployees();

    EmployeeDto updateEmployee(int employeeId, EmployeeDto updatedEmployee);

    void deleteEmployee(int employeeId);

//	EmployeeDto createEmployee(EmployeeDto employeeDto);
//	EmployeeDto getEmployeeById(int employeeId);
//
//	List<EmployeeDto> getAllEmployees();
//	
//	EmployeeDto updateEmployee(int employeeId,EmployeeDto updatedEmployee);
//	
//	void deleteEmployee(int employeeId);
	
}
