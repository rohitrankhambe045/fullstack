	package com.javabackendev.backend.mapper;

import com.javabackendev.backend.entity.Employee;
import com.javabackendev.backend.dto.EmployeeDto;
import com.javabackendev.backend.dto.*;
public class EmployeeMapper {

	
	public static EmployeeDto mapToEmployeeDto(Employee employee){
        return new EmployeeDto(
                employee.getId(),
                employee.getFirstName(),
                employee.getLastName(),
                employee.getEmail()
               
        );
    }

	//updating code for adding department for employee 
	public static Employee mapToEmployee(EmployeeDto employeeDto)
	{
		Employee employee  = new Employee();
		employee.setId(employeeDto.getId());
		employee.setFirstName(employeeDto.getFirstName());
		employee.setLastName(employeeDto.getLastName());
		employee.setEmail(employeeDto.getEmail());
		return employee;
	
	}
}
	
	
	
//    public static Employee mapToEmployee(EmployeeDto employeeDto){
//        return new Employee(
//                employeeDto.getId(),
//                employeeDto.getFirstName(),
//                employeeDto.getLastName(),
//                employeeDto.getEmail()
//        );
//    }
	
	
	
	
//	public static EmployeeDto mapToEmployeeDto(Employee employee)
//	{
//		return new EmployeeDto(
//				employee.getId(),
//				employee.getEmail(),
//				employee.getFirstName(),
//				employee.getLastName()
//				);
//	}
//	public static Employee mapToEmployee(EmployeeDto employeeDto)
//	{
//		return new Employee(
//				employeeDto.getId(),
//				employeeDto.getFirstName(),
//				employeeDto.getLastName(),
//				employeeDto.getEmail()
//				);
//	}
//}
