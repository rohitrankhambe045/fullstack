package com.javabackendev.backend.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.javabackendev.backend.dto.EmployeeDto;
import com.javabackendev.backend.entity.Department;
import com.javabackendev.backend.entity.Employee;
import com.javabackendev.backend.exception.ResourceNotFoundException;
import com.javabackendev.backend.mapper.EmployeeMapper;
import com.javabackendev.backend.repository.DepartmentRepository;
import com.javabackendev.backend.repository.EmployeeRepository;
import com.javabackendev.backend.service.EmployeeService;
import lombok.AllArgsConstructor;

import java.util.List;
import java.util.stream.Collectors;
//service method creates spring bean for this class
@Service
@AllArgsConstructor
public class EmployeeServiceImpl implements EmployeeService{

	private final EmployeeRepository employeeRepository;

	private DepartmentRepository departmentRepository;
	
	
	
	public EmployeeServiceImpl(EmployeeRepository employeeRepository)
	{
		this.employeeRepository = employeeRepository;
	}
    @Override
    public EmployeeDto createEmployee(EmployeeDto employeeDto) {

        Employee employee = EmployeeMapper.mapToEmployee(employeeDto);
        
    
        Employee savedEmployee = employeeRepository.save(employee);
        return EmployeeMapper.mapToEmployeeDto(savedEmployee);
    }

    @Override
    public EmployeeDto getEmployeeById(int employeeId) {
        Employee employee = employeeRepository.findById(employeeId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Employee is not exists with given id : " + employeeId));

        return EmployeeMapper.mapToEmployeeDto(employee);
    }

    @Override
    public List<EmployeeDto> getAllEmployees() {
        List<Employee> employees = employeeRepository.findAll();
        return employees.stream().map((employee) -> EmployeeMapper.mapToEmployeeDto(employee))
                .collect(Collectors.toList());
    }

    @Override
    public EmployeeDto updateEmployee(int employeeId, EmployeeDto updatedEmployee) {

        Employee employee = employeeRepository.findById(employeeId).orElseThrow(
                () -> new ResourceNotFoundException("Employee is not exists with given id: " + employeeId)
        );

        employee.setFirstName(updatedEmployee.getFirstName());
        employee.setLastName(updatedEmployee.getLastName());
        employee.setEmail(updatedEmployee.getEmail());

        Employee updatedEmployeeObj = employeeRepository.save(employee);

        return EmployeeMapper.mapToEmployeeDto(updatedEmployeeObj);
    }

    @Override
    public void deleteEmployee(int employeeId) {

        Employee employee = employeeRepository.findById(employeeId).orElseThrow(
                () -> new ResourceNotFoundException("Employee is not exists with given id: " + employeeId)
        );

        employeeRepository.deleteById(employeeId);
    }
	
//	public EmployeeServiceImpl(EmployeeRepository employeeRepository) {
//		super();
//		this.employeeRepository = employeeRepository;
//	}
//
//	private EmployeeRepository employeeRepository;
//	
//	@Override
//	public EmployeeDto createEmployee(EmployeeDto employeeDto) {
//		Employee employee = EmployeeMapper.mapToEmployee(employeeDto);
//		Employee savedEmployee = employeeRepository.save(employee);
//		return EmployeeMapper.mapToEmployeeDto(savedEmployee);
//	}
//
//	@Override
//	public EmployeeDto getEmployeeById(int employeeId) {
//		// TODO Auto-generated method stub
//		Employee employee = employeeRepository.findById(employeeId)
//		.orElseThrow(() -> new ResourceNotFoundException("Employee not found with id"+employeeId));
//		return EmployeeMapper.mapToEmployeeDto(employee);
//	}
//
//	
//	public List<EmployeeDto> getAllEmployees() {
//		List<Employee> employees = employeeRepository.findAll();
//		// TODO Auto-generated method stub
//		return employees.stream().map((employee) -> EmployeeMapper.mapToEmployeeDto(employee)).collect(Collectors.toList());
//	}
//
//	@Override
//	public EmployeeDto updateEmployee(int employeeId, EmployeeDto updatedEmployee) {
//		Employee employee = employeeRepository.findById(employeeId).orElseThrow(
//				() -> new ResourceNotFoundException("employee does not exist with given id"+employeeId)
//				);
//		employee.setFirstName(updatedEmployee.getFirstName());
//		employee.setLastName(updatedEmployee.getLastName());
//		employee.setEmail(updatedEmployee.getEmail());
//		
//		Employee updatedEmployeeobj = employeeRepository.save(employee);
//		// TODO Auto-generated method stub
//		return EmployeeMapper.mapToEmployeeDto(updatedEmployeeobj);
//	}
//
//	@Override
//	public void deleteEmployee(int employeeId) {
//		Employee employee = employeeRepository.findById(employeeId).orElseThrow(
//				() -> new ResourceNotFoundException("employee does not exist with given id"+employeeId)
//				);
//		employeeRepository.deleteById(employeeId);
//		
//		
//		
//	}
	
	

}
