package com.javabackendev.backend.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class EmployeeDto {

	
	   private int id;
	    private String firstName;
	    private String lastName;
	    private String email;
//		public EmployeeDto(int id, String firstName, String lastName, String email) {
//			super();
//			this.id = id;
//			this.firstName = firstName;
//			this.lastName = lastName;
//			this.email = email;
//		}
	    
	   
	
	    
	    
		public int getId() {
			return id;
		}
		public EmployeeDto(int id, String firstName, String lastName, String email) {
	super();
	this.id = id;
	this.firstName = firstName;
	this.lastName = lastName;
	this.email = email;

}
		
		
		public void setId(int id) {
			this.id = id;
		}
		public String getFirstName() {
			return firstName;
		}
		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}
		public String getLastName() {
			return lastName;
		}
		public void setLastName(String lastName) {
			this.lastName = lastName;
		}
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		
	    
	
    
	
//	private int id;
//	private String email;
//	private String firstname;
//	private String lastname;
//	public int getId() {
//		return id;
//	}
//	public void setId(int id) {
//		this.id = id;
//	}
//	public String getEmail() {
//		return email;
//	}
//	public void setEmail(String email) {
//		this.email = email;
//	}
//	public String getFirstname() {
//		return firstname;
//	}
//	public void setFirstname(String firstname) {
//		this.firstname = firstname;
//	}
//	public String getLastname() {
//		return lastname;
//	}
//	public void setLastname(String lastname) {
//		this.lastname = lastname;
//	}
//	public EmployeeDto(int id, String email, String firstname, String lastname) {
//		super();
//		this.id = id;
//		this.email = email;
//		this.firstname = firstname;
//		this.lastname = lastname;
//	}
//	public EmployeeDto() {
//		super();
//	}
//	
	
	
}
